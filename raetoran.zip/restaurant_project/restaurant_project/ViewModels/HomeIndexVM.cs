﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using restaurant_project.Models;

namespace restaurant_project.ViewModels
{
    public class HomeIndexVM
    {
        public IEnumerable<Slider> Sldiers { get; set; }

        public Contact Contact { get; set; }

        public IEnumerable<Meal> Meals { get; set; }
    }
}
