﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using restaurant_project.DAL;
using restaurant_project.Models;


namespace restaurant_project.ViewModels
{
    public class SalesIndexVM
    {
        public Order Order { get; set; }

        public Meal Meal { get; set; }


        public AppUser AppUser { get; set; }
    }
}
