﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using restaurant_project.Models;

namespace restaurant_project.ViewModels
{
    public class UserAddRoleVM
    {
        public AppUser AppUser { get; set; }

        public IEnumerable<string> Roles { get; set; }
    }
}
