﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using restaurant_project.Models;
namespace restaurant_project.ViewModels
{
    public class CreateOrderVM
    {
        public Meal Meal { get; set; }


        public AppUser AppUser { get; set; }

        public Order Order { get; set; }


    }
}
