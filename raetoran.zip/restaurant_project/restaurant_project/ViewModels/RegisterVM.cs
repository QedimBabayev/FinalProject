﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace restaurant_project.ViewModels
{
    public class RegisterVM
    {

        [Required(ErrorMessage = "Email must be filled")]
        [MinLength(5)]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        [Required(ErrorMessage = "Username must be filled")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Firstname must be filled")]
        [MinLength(3)]
        public string Firstname { get; set; }
        public string Lastname { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required, Compare(nameof(Password))]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
    }
}
