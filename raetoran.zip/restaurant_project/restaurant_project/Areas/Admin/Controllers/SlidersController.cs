﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using restaurant_project.DAL;
using restaurant_project.Models;
using Microsoft.AspNetCore.Hosting;
using restaurant_project.Extension;
using restaurant_project.Utilites;
using Microsoft.AspNetCore.Authorization;

namespace restaurant_project.Areas.Admin.Controllers
{

    [Area("Admin")]
    [Authorize(Roles = "Admin")]

    public class SlidersController : Controller
    {

        private readonly FrontContext _context;
        private readonly IHostingEnvironment _env;
        public SlidersController(FrontContext context, IHostingEnvironment env)
        {
            _context = context;
            _env = env;
        }
        public IActionResult Index(int page=1)
        {
            var skipCount = ((page - 1) * 3);
            var sliders = _context.Sliders.OrderBy(s=>s.Id).Skip(skipCount).Take(3).ToList();

            ViewData["total_slider_count"] = _context.Sliders.ToList().Count;
            ViewData["active_page"] = page;

            return View(sliders);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Slider slider)
        {
            if (!ModelState.IsValid)
            {
                return View(slider);
            }

            //1.check whether photo is not null
            //2.check photo is a valid image
            //3.Create unique name for new photo
            //4.save new photo in images folder
            //5.save photo name in sql


            if (slider.Photo == null)
            {
                ModelState.AddModelError("Photo", "Photo should be selected");
                return View(slider);
            }
            if (!slider.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Photo is not valid");
                return View(slider);

            }

            slider.Image = await slider.Photo.SaveFileAsync(_env.WebRootPath);
            await _context.Sliders.AddAsync(slider);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));

        }


        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var slider = await _context.Sliders.FindAsync(id);

            if (slider == null) return NotFound();

            return View(slider);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var slider = await _context.Sliders.FindAsync(id);

            if (slider == null) return NotFound();


            return View(slider);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, Slider slider)
        {
            if (!ModelState.IsValid) return View(slider);
            Slider sliderFromDb = await _context.Sliders.FindAsync(id);

            if (slider.Photo != null)
            {
                if (slider.Photo.IsImage())
                {
                    //remove old slider image
                    Utilities.RemoveFile(sliderFromDb.Image, _env.WebRootPath);
                    //save new slider image
                    sliderFromDb.Image = await slider.Photo.SaveFileAsync(_env.WebRootPath);


                }
                else
                {
                    ModelState.AddModelError("Photo", "Photo is invalid");
                    return View(slider);
                }

            }

            sliderFromDb.MaindHeading = slider.MaindHeading;
            sliderFromDb.MainText = slider.MainText;
            sliderFromDb.Subheading = slider.Subheading;
            sliderFromDb.ImageAlt = slider.ImageAlt;

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));

        }


        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var slider = await _context.Sliders.FindAsync(id);

            if (slider == null) return NotFound();


            return View(slider);
        }
        [HttpPost]
        [AutoValidateAntiforgeryToken]
        [ActionName("Delete")]
        public async Task<IActionResult> DeletePost(int? id)
        {

            if (id == null) return NotFound();
      

            Slider slider = await _context.Sliders.FindAsync(id);

            if (slider == null) return NotFound();
            if (_context.Sliders.ToList().Count > 1)
            {
                Utilites.Utilities.RemoveFile(slider.Image, _env.WebRootPath);
                _context.Sliders.Remove(slider);
                await _context.SaveChangesAsync();
            }

            
            return RedirectToAction(nameof(Index));
        }
    }
}