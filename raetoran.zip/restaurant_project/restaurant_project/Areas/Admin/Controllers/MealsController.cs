﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using restaurant_project.DAL;
using restaurant_project.Models;
using restaurant_project.ViewModels;
using Microsoft.AspNetCore.Hosting;
using restaurant_project.Extension;
using restaurant_project.Utilites;
using Microsoft.AspNetCore.Authorization;

namespace restaurant_project.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]

    public class MealsController : Controller
    {

        private readonly FrontContext _context;
        private readonly IHostingEnvironment _env;


        public MealsController(FrontContext context, IHostingEnvironment env)
        {
            _context = context;
            _env = env;
        }
        public IActionResult Index()
        {


            var meals = _context.Meals.ToList();
        
            return View(meals);
        }

        public IActionResult Create()
        {

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Meal meal)
        {
            if (!ModelState.IsValid) return View(meal);


            if (meal.Photo == null)
            {
                ModelState.AddModelError("Photo", "Photo sholud be selected");
                return View(meal);

            }

            meal.Image = await meal.Photo.SaveFileAsync(_env.WebRootPath);
    
            await _context.Meals.AddAsync(meal);
            await _context.SaveChangesAsync();



            return RedirectToAction(nameof(Index));
        }


        public async Task<IActionResult> Details(int? id)
        {
           

            if (id == null) return NotFound();

            var meal = await _context.Meals.FindAsync(id);
            var category = _context.Categories.FirstOrDefault(f => f.Id == meal.CategoryId);
         
         
         
           

            if (meal == null) return NotFound();

            AdminDetailsVM adminDetailsVM = new AdminDetailsVM
            {
                Category = category,
                Meals = meal
            };
       

            return View(adminDetailsVM);
        }


        public async Task<IActionResult> Edit(int? id)
        {

            if (id == null) return NotFound();

            var meal = await _context.Meals.FindAsync(id);
            meal.CategoryName = _context.Categories.FirstOrDefault(c => c.Id == meal.CategoryId).Name;

            if (meal == null) return NotFound();


            return View(meal);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, Meal meals)
        {

            if (!ModelState.IsValid) return View(meals);
            Meal mealFromDB = await _context.Meals.FindAsync(id);

          
            //_context.Meals.Where(m => m.CategoryName == "Pizza").;
            //_context.Meals.Where(m => m.CategoryName == "Burgers").ToList();
           


            if (meals.Photo != null)
            {

                if (meals.Photo.IsImage())
                {
                    Utilities.RemoveFile(mealFromDB.Image, _env.WebRootPath);

                    mealFromDB.Image = await meals.Photo.SaveFileAsync(_env.WebRootPath);
                }
                else
                {
                    ModelState.AddModelError("Photo", "Photo is invalid");
                    return View(meals);
                }

            }

            mealFromDB.Name = meals.Name;
            mealFromDB.Price = meals.Price;
            mealFromDB.Contex = meals.Contex;
            mealFromDB.CategoryName = meals.CategoryName;
            if (mealFromDB.CategoryName == "Pizza")
            {
                mealFromDB.CategoryId = 1;


            }

            else if (mealFromDB.CategoryName == "Burgers")
            {
                mealFromDB.CategoryId = 2;

            }
            if(meals.CategoryName == "Pizza")
            {
                meals.CategoryId = 1;
            }
            else if(meals.CategoryName == "Burgers")
            {
                meals.CategoryId = 2;
            }
            if (mealFromDB.CategoryName == "Pasta")
            {
                mealFromDB.CategoryId = 1002;


            }

            else if (mealFromDB.CategoryName == "Drinks")
            {
                mealFromDB.CategoryId = 3;

            }
            if (meals.CategoryName == "Pasta")
            {
                meals.CategoryId = 1002;
            }
            else if (meals.CategoryName == "Drinks")
            {
                meals.CategoryId = 3;
            }


            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));

        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var meal= await _context.Meals.FindAsync(id);

            if (meal== null) return NotFound();

            return View(meal);

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]
        public async Task<IActionResult> DeletePost(int? id)
        {

            if (id == null) return NotFound();

          Meal meals= await _context.Meals.FindAsync(id);

            if (meals== null) return NotFound();

            if (_context.Meals.ToList().Count > 1)
            {
             Utilities.RemoveFile(meals.Image, _env.WebRootPath);
                _context.Meals.Remove(meals);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }
    }
}