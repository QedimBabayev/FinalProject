﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using restaurant_project.Models;
using Microsoft.AspNetCore.Authorization;
using restaurant_project.DAL;
using restaurant_project.ViewModels;

namespace restaurant_project.Areas.Admin.Controllers
{

    [Area("Admin")]
    [Authorize(Roles = "Admin")]


    public class SalesController : Controller
    {
        private readonly FrontContext _context;

        private readonly UserManager<AppUser> _userManager;

        public SalesController(FrontContext context, UserManager<AppUser> userManager)
        {
            _context = context;
            _userManager = userManager;

        }
        public IActionResult Index()
        {

            var orders = _context.Orders.ToList();
            

            return View(orders);
        }

        public IActionResult Delete()
        {
            var orders = _context.Orders.ToList();

            _context.Orders.RemoveRange(orders);
            _context.SaveChanges();

            return RedirectToAction("Index", "Sales");
        }
    }
}