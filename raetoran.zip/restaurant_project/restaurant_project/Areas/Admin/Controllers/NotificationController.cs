﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using restaurant_project.Models;
using Microsoft.AspNetCore.Authorization;
using restaurant_project.ViewModels;
using restaurant_project.DAL;
namespace restaurant_project.Areas.Admin.Controllers
{
    public class NotificationController : Controller
    {


        private readonly UserManager<AppUser> _userManager;
        private readonly FrontContext _context;

        public NotificationController(FrontContext context, UserManager<AppUser> userManager)
        {
            _context = context;
            _userManager = userManager;

        }

        public IActionResult Notifications()
        {



            return View();
        }

        //public async Task<IActionResult> CreateNotification(Order order)
        //{

        //    Notification not = new Notification();
        //    not.Order.OrderId = order.OrderId;
        //    not.AppUser.Id = order.AppUserId;
        //    not.UserName = order.AppUser.UserName;
        //    not.CreatedAt = DateTime.Now;

        //    await _context.Notifications.AddAsync(not);
        //    await _context.SaveChangesAsync();


        //    return Content("bildiris geldi");
        //}
    }
}