﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using restaurant_project.Models;
using restaurant_project.DAL;

namespace restaurant_project.Areas.ViewComponents
{
  
    [ViewComponent(Name ="Notification")]
    public class NotificationViewComponent : ViewComponent
    {
        private readonly FrontContext _context;

        public NotificationViewComponent(FrontContext context)
        {
            _context = context;
        }
        public IViewComponentResult Invoke()
        {
            var not =  _context.Notifications.OrderByDescending(n=>n.CreatedAt).ToList();
            
            return View("Index",not);
        }


    }
}
