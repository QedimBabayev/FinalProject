﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations.Schema;

namespace restaurant_project.Models
{
    public class Notification
    {
        public int Id { get; set; }

        public string UserName { get; set; }

     
        public int OrderId { get; set; }

        public string AppUserId { get; set; }



        public DateTime CreatedAt { get; set; }

        public virtual AppUser AppUser { get; set; }

        public virtual Order Order { get; set; }
    }
}
