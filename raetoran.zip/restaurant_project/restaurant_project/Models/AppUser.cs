﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations.Schema;

namespace restaurant_project.Models
{
    public class AppUser : IdentityUser
    {

        [StringLength(50)]
        [Required]
        public string Firstname { get; set; }
        [StringLength(50)]
        public string Lastname { get; set; }

        public DateTime Birthdate { get; set; }
        [StringLength(255)]
        public string Image { get; set; }
        [NotMapped]
        public IFormFile  MyProperty{ get; set; }




        public virtual ICollection<Order> Orders { get; set; }
        public virtual ICollection<Notification> Notifications{ get; set; }




    }
}
