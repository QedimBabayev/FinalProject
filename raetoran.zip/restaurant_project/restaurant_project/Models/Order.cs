﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace restaurant_project.Models
{
    public class Order
    {
        public int OrderId { get; set; }

        public string Firstname { get; set; }

        public string Lastname { get; set; }
        [StringLength(100)]
        [Required]
        public string Adress { get; set; }

        public string AppUserId { get; set; }

        public int MealId { get; set; }
        [StringLength(100)]
        public string MealName { get; set; }

        public decimal Price { get; set; }

        public int Quantity { get; set; }

        public decimal TotalPrice { get; set; }

        public virtual AppUser AppUser { get; set; }


        public virtual Meal Meal { get; set; }

        public virtual ICollection<Notification> Notifications { get; set; }

    }
}
