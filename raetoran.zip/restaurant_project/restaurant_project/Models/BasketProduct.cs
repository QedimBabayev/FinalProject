﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace restaurant_project.Models
//{
//    public class BasketProduct
//    {
//        public int Id { get; set; }
     
//        public string Image { get; set; }
        
//        public string Name { get; set; }
        
//        public string Contex { get; set; }
//        public decimal Price { get; set; }
//        public Category Category { get; set; }

//        public int Quantity { get; set; }

//        public string AppUserId { get; set; }

//        public virtual AppUser AppUser { get; set; }



//    }
//}
