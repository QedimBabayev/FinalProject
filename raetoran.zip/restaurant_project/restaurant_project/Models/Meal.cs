﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace restaurant_project.Models
{
    public class Meal
    {
        public int Id { get; set; }
        [StringLength(255)]
        public string Image { get; set; }
        [StringLength(100)]
        public string Name { get; set; }
        [StringLength(200)]
        public string Contex { get; set; }
        public decimal Price { get; set; }
        public Category Category { get; set; }
        public int CategoryId { get; set; }

        public virtual ICollection<Order> Orders { get; set; }

        [NotMapped]
        public string CategoryName { get; set; }




        [NotMapped]
        public IFormFile Photo { get; set; }

        //public static implicit operator BasketProduct(Meal meals)
        //{
        //    return new BasketProduct
        //    {
        //        Id = meals.Id,
        //        Name = meals.Name,
        //        Price = meals.Price,
        //        Contex = meals.Contex,
        //        Category = meals.Category,
        //        Image = meals.Image,

        //        Quantity = 1
        //    };
        //}

    }
    


   
}
