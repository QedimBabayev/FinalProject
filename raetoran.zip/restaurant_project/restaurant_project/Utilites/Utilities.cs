﻿using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace restaurant_project.Utilites
{
    public static class Utilities
    {
        public static void RemoveFile(string file, string webrootpath)
        {
            string path = webrootpath + @"\image\" +file;

            if (File.Exists(path))
            {
                File.Delete(path);
            }
        }

        public static string IsActive(this HtmlHelper html,
                                 string control,
                                 string action)
        {
            var routeData = html.ViewContext.RouteData;

            var routeAction = (string)routeData.Values["action"];
            var routeControl = (string)routeData.Values["controller"];

            // both must match
            var returnActive = control == routeControl &&
                               action == routeAction;

            return returnActive ? "active" : "";
        }
    }
}
