﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using restaurant_project.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;


namespace restaurant_project.DAL
{
    public class FrontContext :IdentityDbContext<AppUser>

    {
        public FrontContext(DbContextOptions<FrontContext> options) :base(options)
        {

        }

        public DbSet <Slider> Sliders { get; set; }

        public DbSet <Contact> Contacts { get; set; }

        public DbSet <Meal>  Meals { get; set; }

        public DbSet<Category> Categories { get; set; }

        public DbSet<Order> Orders { get; set; }

        public DbSet<Notification> Notifications { get; set; }


        public DbSet<ContactUs> ContactUs { get; set; }
        public DbSet<ContactForm> ContactForms { get; set; }
    }
}
