﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Mvc;
//using restaurant_project.Models;
//using restaurant_project.DAL;
//using restaurant_project.ViewModels;
//using Microsoft.AspNetCore.Http;
//using Newtonsoft.Json;
//using Microsoft.AspNetCore.Identity;
//namespace restaurant_project.Controllers
//{
//    public class CardController : Controller
//    {
//        private readonly FrontContext _context;
//        private readonly UserManager<AppUser> _userManager;

//        public CardController(FrontContext context, UserManager<AppUser> userManager)
//        {
//            _context = context;
//            _userManager = userManager;
//        }
//        public async Task<IActionResult> Add(int id)
//        {
//            Meal meal = await _context.Meals.FindAsync(id);
//            BasketProduct basketProduct = meal;


//            string card = HttpContext.Session.GetString("card");

//            List<BasketProduct> meals = new List<BasketProduct>();

//            if(card != null)
//            {
//                meals = JsonConvert.DeserializeObject<List<BasketProduct>>(card);
//            }

//            var selected = meals.FirstOrDefault(m => m.Id == id);

//            if(selected == null)
//            {
//                meals.Add(meal);
//            }
//            else
//            {
//                selected.Quantity +=1;
//            }

           
           

//            string mealsJSON = JsonConvert.SerializeObject(meals);

//            HttpContext.Session.SetString("card", mealsJSON);


//            return RedirectToAction("Index","Home");
//        }

//          public IActionResult Remove(int id)
//        {

//            string card = HttpContext.Session.GetString("card");
//            List<Meal> meals= new List<Meal>();

//            if (card != null)
//            {
//                meals= JsonConvert.DeserializeObject<List<Meal>>(card);
//            }
//            Meal  meal= meals.FirstOrDefault(f => f.Id == id);
//            meals.Remove(meal);
//            string mealsJSON = JsonConvert.SerializeObject(meals);
//            HttpContext.Session.SetString("card", mealsJSON);
//            return RedirectToAction("Checkout", "Card");
//        }
//        public IActionResult Checkout()
//        {

//            string card = HttpContext.Session.GetString("card");
//            List<BasketProduct> meals = new List<BasketProduct>();

//            if (card != null)
//            {
//                meals = JsonConvert.DeserializeObject<List<BasketProduct>>(card);
//            }
        

//            return View(meals);
//        }

//    }
//} 