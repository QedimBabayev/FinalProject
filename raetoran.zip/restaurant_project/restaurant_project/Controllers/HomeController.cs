﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using restaurant_project.Models;
using restaurant_project.DAL;
using restaurant_project.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using System.Net.Mail;
using System.Net;
using Microsoft.Extensions.Localization;
using Microsoft.AspNetCore.Localization;
using static Microsoft.AspNetCore.Hosting.Internal.HostingApplication;
using System.Security.Policy;
using Microsoft.AspNetCore.Authorization;

namespace restaurant_project.Controllers
{


    public class HomeController : Controller
    {
        private readonly FrontContext _context;
        private readonly UserManager<AppUser> _userManager;
        private readonly IStringLocalizer<HomeController> _localizer;





        public HomeController(FrontContext context, UserManager<AppUser> userManager, IStringLocalizer<HomeController> localizer)
        {
            _context = context;
            _userManager = userManager;
            _localizer = localizer;


        }
        public IActionResult Index()
        {

            IEnumerable<Slider> sliders = _context.Sliders.ToList();
            Contact contact = _context.Contacts.First();
            IEnumerable <Meal> meals = _context.Meals.ToList();
            HomeIndexVM homeIndexVM = new HomeIndexVM
            {
                Sldiers = sliders,
                Contact = contact,
                Meals = meals

            };
            return View(homeIndexVM);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]




        public IActionResult SetLanguage(string culture, string returnUrl)
        {
            Response.Cookies.Append(
               CookieRequestCultureProvider.DefaultCookieName,
               CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture)),
               new CookieOptions {Expires = DateTimeOffset.UtcNow.AddYears(1),
               IsEssential= true}



                );

            

            return Redirect(returnUrl);

        }
       

        public IActionResult ValidateMessage()
        {

            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Send(IFormCollection collection)
        {
                

            ContactUs cs = new ContactUs();
            cs.Name = collection["name"];
            cs.Email = collection["email"];
            cs.Subject = collection["message"];
            cs.Message = collection["textmessage"];

             await  _context.ContactUs.AddAsync(cs);
            var email = cs.Email;
          if( await _context.SaveChangesAsync() > 0)
            {
                MailMessage mail = new MailMessage();

                mail.To.Add("qedimbabayev99@gmail.com");//mail gonderilen address

                mail.From =new MailAddress(email);
                mail.Subject = "elaqe";
                string Body =
                    "AD Soyad: " + collection["name"] + " </br>E-Mail : " + collection["email"] + " </br>Subject : " + collection["message"] +  " </br>Message : " + collection["textmessage"];
                mail.Body = Body;
                mail.IsBodyHtml = true;
                 SmtpClient smp = new SmtpClient();
                smp.Credentials = new NetworkCredential()
                {
                    UserName = "qedimbabayev99@gmail.com",
                    Password = "qedimyek"
                };
                smp.Port = 587;
                smp.Host = "smtp.gmail.com";
                smp.EnableSsl = true;
                smp.Send(mail);
            }






            return RedirectToAction(nameof(ValidateMessage));
        }

        public IActionResult Menu()
        {

            Contact contact = _context.Contacts.First();
            IEnumerable<Meal> meals = _context.Meals.ToList();

            HomeIndexVM homeIndexVM = new HomeIndexVM
            {
                Contact = contact,
                Meals = meals

            };

            return View(homeIndexVM);
        }
        public IActionResult Services()
        {

            Contact contact = _context.Contacts.First();
            IEnumerable<Meal> meals = _context.Meals.ToList();

            HomeIndexVM homeIndexVM = new HomeIndexVM
            {
                Contact = contact,
                Meals = meals

            };

            return View(homeIndexVM);
        }

        public IActionResult About()
        {

            Contact contact = _context.Contacts.First();
            IEnumerable<Meal> meals = _context.Meals.ToList();

            HomeIndexVM homeIndexVM = new HomeIndexVM
            {
                Contact = contact,
                Meals = meals

            };

            return View(homeIndexVM);
        }
        public IActionResult Contact()
        {

            Contact contact = _context.Contacts.First();
            IEnumerable<Meal> meals = _context.Meals.ToList();

            HomeIndexVM homeIndexVM = new HomeIndexVM
            {
                Contact = contact,
                Meals = meals

            };

            return View(homeIndexVM);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
