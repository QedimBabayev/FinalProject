﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using restaurant_project.Models;
using restaurant_project.ViewModels;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Net;

namespace restaurant_project.Controllers
{
    public class AuthController : Controller
    {

        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;
        private readonly ILogger<AuthController> _logger;


        public AuthController(UserManager<AppUser> userManager, SignInManager<AppUser> signInManager, ILogger<AuthController> logger)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _logger = logger;
        }
        public IActionResult Register()
        {
            return View();
        }


       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterVM registerVM)
        {

            if (!ModelState.IsValid)
            {
                return View(registerVM);

            }

            AppUser appUser = new AppUser
            {
                Email = registerVM.Email,
                Firstname = registerVM.Firstname,
                Lastname = registerVM.Lastname,
                UserName = registerVM.UserName,

            };




            IdentityResult result = await _userManager.CreateAsync(appUser, registerVM.Password);

            if (result.Succeeded)
            {

                string token = await _userManager.GenerateEmailConfirmationTokenAsync(appUser);
                string ctokenlink = Url.Action("ConfirmEmail", "Auth",
                    new { appUserId = appUser.Id, token = token }, Request.Scheme
                    );
                _logger.Log(LogLevel.Warning, ctokenlink);

                MailMessage mail = new MailMessage();
                mail.IsBodyHtml = true;
                mail.To.Add(appUser.Email);
                string address = "qedimbabayev99@gmail.com";
                string displayName = "verification link";

                mail.From = new MailAddress(address, displayName, System.Text.Encoding.UTF8);
                mail.Subject = "Saytdan gelen dogrulama linki";
                mail.Body = "Mail:" + appUser.Email + "Please verify your email address to finish your account registration" + "You can  click the link below to complete the registration or copy the following linkin to the address bar of your browser to complete the registration." + 
                    "Link:"
                    + ctokenlink;
                mail.IsBodyHtml = true;
                SmtpClient smp = new SmtpClient();
                smp.Credentials = new NetworkCredential()
                {
                    UserName = "qedimbabayev99@gmail.com",
                    Password = "qedimyek"
                };
                smp.Port = 587;
                smp.Host = "smtp.gmail.com";
                smp.EnableSsl = true;
                smp.Send(mail);
                return RedirectToAction("Confirming","Auth", new {id = appUser.Id });
            }

            else
            {
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
                return View(registerVM);
            }

        }
        public async Task<IActionResult> Confirming(string id)
        {
            var user = await _userManager.FindByIdAsync(id);

           


            return View(user);
        }

        [HttpGet]
        [AllowAnonymous]

        public async Task<IActionResult> ConfirmEmail(string appUserId, string token)
        {



            if (appUserId == null || token == null)
            {
                return RedirectToAction("Index", "Home");

            }

            var user = await _userManager.FindByIdAsync(appUserId);


            if (user == null)
            {
                ViewBag.ErrorMessage = $"The user id {appUserId} is invalid";
                return NotFound();
            }

            var result = await _userManager.ConfirmEmailAsync(user, token);

            if (result.Succeeded)
            {
                return RedirectToAction("Login", "Auth");
            }
            ViewBag.ErrorTitle = "Email cannot be confirmed";
            return View("Error");
        }


        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginVM loginVM)
        {
            if (!ModelState.IsValid) return View(loginVM);

            AppUser user = await _userManager.FindByEmailAsync(loginVM.Email);
            if (user == null && user.EmailConfirmed == false)
            {
                ModelState.AddModelError("", "Email or password is invalid");
                return View(loginVM);
            }
            var result = await _signInManager.PasswordSignInAsync(user, loginVM.Password, loginVM.RememberMe, true);

            if (result.Succeeded)
            {
                return RedirectToAction("Index", "Home");
            }

            ModelState.AddModelError("", "Email or password is invalid");
            return View(loginVM);

        }

        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }


    
    }
}