﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using restaurant_project.Models;
using restaurant_project.DAL;
using restaurant_project.ViewModels;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Identity;

namespace restaurant_project.Controllers
{
    public class OrderController : Controller
    {
        private readonly FrontContext _context;
        private readonly UserManager<AppUser> _userManager;


        public OrderController(FrontContext context, UserManager<AppUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }
        public async  Task<IActionResult> Index(int? id)
        {
            if (id == null) return NotFound();

            var product = await _context.Meals.FindAsync(id);
            var order =  _context.Orders.FirstOrDefault(o => o.MealId == id);

            MealOrderVM mealOrderVM = new MealOrderVM
            {
                Order = order,
                Meal = product
            };

            if (product == null) return NotFound();

            return View(mealOrderVM);
        }

        public async Task<IActionResult> CreateOrder(int? id)
        {
            if (id == null) return NotFound();

            var product = await _context.Meals.FindAsync(id);
            var order = _context.Orders.FirstOrDefault(o => o.MealId == id);
            MealOrderVM mealOrderVM = new MealOrderVM
            {
                Order = order,
                Meal = product
            };


            if (product == null) return NotFound();

            return View(mealOrderVM);
        }
        public IActionResult Sent()
        {
           

            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateOrder(Order order, int? id)
        {
            if (!ModelState.IsValid) return View(order);

            AppUser user = await _userManager.FindByNameAsync(User.Identity.Name);

            var meal = _context.Meals.FirstOrDefault(m => m.Id == id);

            order.MealId= meal.Id;
            order.MealName= meal.Name;
            order.Price= meal.Price;
            order.AppUserId = user.Id;
            order.Firstname = user.Firstname;
            order.Lastname = user.Lastname;
            order.TotalPrice = order.Quantity * order.Price;
            await _context.Orders.AddAsync(order);

            Notification not = new Notification();
            not.OrderId = order.OrderId;
            not.AppUserId= order.AppUserId;
            not.UserName = order.Firstname;
            not.CreatedAt = DateTime.Now;

            await _context.Notifications.AddAsync(not);


            await _context.SaveChangesAsync();







            return RedirectToAction("Sent", "Order"); 
        }

        public async Task<IActionResult> Profile()
        {
            AppUser user = await _userManager.FindByNameAsync(User.Identity.Name);
            var orders = _context.Orders.Where(o => o.AppUserId == user.Id).ToList();

            return View(orders);
        }

        public IActionResult Delete()
        {
            var orders = _context.Orders.ToList();

            _context.Orders.RemoveRange(orders);
            _context.SaveChanges();

            return RedirectToAction(nameof(Profile));
        }

        public  IActionResult DeleteOne(int? id)
        {
            var selectedOrder =  _context.Orders.FirstOrDefault(o=>o.OrderId == id);

            _context.Orders.Remove(selectedOrder);
            _context.SaveChanges();

            return RedirectToAction(nameof(Profile));
        }


    }
}
