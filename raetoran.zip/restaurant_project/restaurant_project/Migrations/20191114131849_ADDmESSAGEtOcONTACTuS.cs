﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace restaurant_project.Migrations
{
    public partial class ADDmESSAGEtOcONTACTuS : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
         

            migrationBuilder.AddColumn<string>(
                name: "Message",
                table: "ContactUs",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Message",
                table: "ContactUs");

            migrationBuilder.AddColumn<int>(
                name: "OrdersId",
                table: "AspNetUsers",
                nullable: false,
                defaultValue: 0);
        }
    }
}
