﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace restaurant_project.Migrations
{
    public partial class CahngeInContactUss : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ContactUs_AspNetUsers_AppUserId",
                table: "ContactUs");

            migrationBuilder.DropIndex(
                name: "IX_ContactUs_AppUserId",
                table: "ContactUs");

            migrationBuilder.RenameColumn(
                name: "AppUserId",
                table: "ContactUs",
                newName: "Name");

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "ContactUs",
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Email",
                table: "ContactUs",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Email",
                table: "ContactUs");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "ContactUs",
                newName: "AppUserId");

            migrationBuilder.AlterColumn<string>(
                name: "AppUserId",
                table: "ContactUs",
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_ContactUs_AppUserId",
                table: "ContactUs",
                column: "AppUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_ContactUs_AspNetUsers_AppUserId",
                table: "ContactUs",
                column: "AppUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
