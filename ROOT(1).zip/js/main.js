"use strict"
$('.owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    // nav:false,
    // dots:false,
    autoplay: true,
    autoplayTimeout: 3000,
    autoplayHoverPause: true,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 1
        }
    }
})
window.onload = function(e){
   const number = [...document.querySelectorAll("#js .increasing span")]
    number.forEach(nm=>{
    let value = nm.getAttribute("data-count");
    let count = 0;
    count = parseInt(nm.innerText);
    setInterval(() => {
        if(count < value && value.length <=3 ){    
            count = count + 1;
            nm.innerHTML = count;           
        } 
    }, 60);
    setInterval(() => {
        if(count < value && value.length >3 ){
            count = count + 1;
            nm.innerHTML = count;            
        }      
    }, 0.001);   
   })
}
$(window).scroll(function () {
    let scroll = jQuery(window).scrollTop();

    if (scroll >= 400) {
        const nav = document.querySelector("#navbar")
        $("#navbar.main").addClass("sticky");
       
        $("#navbar").css("top", "0px");
      
    }
    else {
        $("#navbar").removeClass("sticky")
        $("#navbar").css("top", "-50px")
        $(".navright li.active a ").css("color", "#000");
        $(".navright li:last-of-type").removeClass("cart");
        $(".navright li span.active ").css("color", "#000");
        $("#navbar .navleft .navbar-brand").removeClass("mbl")
  }
})

const navbars = [...document.querySelectorAll("ul.navigation li")];
navbars.forEach(nv => {
    nv.addEventListener("click", function (e) {
        const preactive = document.querySelector("ul.navigation li.active");
        preactive.classList.remove("active");


        nv.classList.add("active");

      


    })

})


const tabButtons =[...document.querySelectorAll("#tabs .btn-holder a")];
tabButtons.forEach(tb=>{
    tb.addEventListener("click", function(e){
        e.preventDefault();
        
        //find preActive class
        const preActive = document.querySelector("#tabs .btn-holder a.main.order.actives");
        const preActiveDiv = document.querySelector("#tabs div.tabContent.active");
        preActive.classList.remove("actives")
        preActiveDiv.classList.remove("active")
       
       
        tb.classList.add("actives");

        //find due to id
       const href = tb.getAttribute("href")
     
        document.querySelector(href).classList.add("active")


    })


})

const mobileMenu = document.querySelector("#mbl-navbar .navRight .icon");
mobileMenu.addEventListener("click", function(){
    
    $("header .mbl-menu").toggleClass("active");
  
})

